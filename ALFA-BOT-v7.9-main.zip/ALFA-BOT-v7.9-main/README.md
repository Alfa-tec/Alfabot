  <p align="center">
    <img alt="" height="300"  src="">
    <h1 align="center">ALFA-BOT</h1>
  </a>
 
 

####  
ALFA-BOT- Simple Multi Device whatsapp bot.

***

#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/Alfa-tec/ALFA-BOT-v7.9/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

2. Scan the QR and upload guru.data.json to your fork(will recieve it on your *WHATSAPP* number after scanning)
   <br>
<a href='https://replit.com/@Alfa-tec/ALFA-BOT-MD-CODE-SCANNER?v=1'    target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



#### DEPLOY TO Heroku 

1. If You don't have an account in Heroku. Create a account.
    <br>
<p align="center"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

2. Now Deploy
    <br>
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Alfa-tec/ALFA-BOT-v7.9"> <img src="https://img.shields.io/badge/Heroku%20Deploy-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

 

- Star ⭐ the repo if you like ALFA-BOT.

#### contact me via whatsapp 👇👇

<p align="center"><a href="https://wa.me/+254110367623"><img src="https://img.shields.io/badge/WhatsApp-green?style=for-the-badge&logo=WhatsApp ME" width="220" height="38.45"/></a>
 
 **THANKS TO** *ALFA*(https://github.com/Alfa-tec/ALFA-BOT-v7.9) | 



